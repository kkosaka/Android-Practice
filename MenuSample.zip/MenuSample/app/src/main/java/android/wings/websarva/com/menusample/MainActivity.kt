package android.wings.websarva.com.menusample

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView
import android.widget.SimpleAdapter
import java.util.*
import kotlin.collections.ArrayList

class MainActivity : AppCompatActivity() {
    val FROM = arrayOf("name", "price")
    val TO = intArrayOf(R.id.tvMenuName, R.id.tvMenuPrice)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var lvMenu = findViewById<ListView>(R.id.lvMenu)
        val menuList = createTeishokuList()
        val adapter = SimpleAdapter(this, menuList, R.layout.row, FROM, TO)
        lvMenu.adapter = adapter

        lvMenu.setOnItemClickListener { parent, view, position, id ->
            val item = parent.getItemAtPosition(position) as Map<String, String>
            val intent = Intent(this, MenuThanksActivity::class.java).apply {
                this.putExtra("menuName", item.get("name"))
                this.putExtra("menuPrice", item.get("price") + "円")
            }
            startActivity(intent)
        }
    }

    private fun createTeishokuList(): ArrayList<Map<String, Any>> {
        val menuList = ArrayList<Map<String, Any>>().apply {
            this.add(HashMap<String, Any>(HashMap<String, Any>().apply {
                this.put("name", "唐揚げ定食")
                this.put("price", 800)
                this.put("desc", "若鳥の唐揚げにサラダ、ご飯とみそ汁がつきます。")
            }))
            this.add(HashMap<String, Any>(HashMap<String, Any>().apply {
                this.put("name", "ハンバーグ定食")
                this.put("price", 900)
                this.put("desc", "ハンバーグにサラダ、ご飯とみそ汁がつきます。")
            }))
            this.add(HashMap<String, Any>(HashMap<String, Any>().apply {
                this.put("name", "サバの味噌煮定食")
                this.put("price", 650)
                this.put("desc", "サバ味噌煮にサラダ、ご飯とみそ汁がつきます。")
            }))
            this.add(HashMap<String, Any>(HashMap<String, Any>().apply {
                this.put("name", "生姜焼き定食")
                this.put("price", 700)
                this.put("desc", "生姜焼きにサラダ、ご飯とみそ汁がつきます。")
            }))
            this.add(HashMap<String, Any>(HashMap<String, Any>().apply {
                this.put("name", "日替わり定食")
                this.put("price", 800)
                this.put("desc", "日替わり料理にサラダ、ご飯とみそ汁がつきます。")
            }))
        }
        return menuList
    }
}

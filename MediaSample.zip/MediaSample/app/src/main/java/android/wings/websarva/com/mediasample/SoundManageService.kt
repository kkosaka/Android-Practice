package android.wings.websarva.com.mediasample

import android.app.Service
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Message
import android.os.Messenger
import java.io.IOException

class SoundManageService : Service() {
    /**
     * 定数
     */
    companion object {
        const val MEDIA_PLAY  = 0
        const val MEDIA_PAUSE = 1
        const val MEDIA_STOP  = 2
    }
    /**
     * メディアプレーヤーフィールド
     */
    private lateinit var _player: MediaPlayer

    /**
     * メッセンジャークラス
     */
    class IncomingHandler : Handler() {
        override fun handleMessage(msg: Message?) {
            when(msg?.what) {
                MEDIA_PLAY -> {
                }
                MEDIA_PAUSE->{

                }
                MEDIA_STOP->{

                }
            }
            return
        }
    }
    /**
     * マネージャー
     */
    private val mMessenger = Messenger(IncomingHandler())


    override fun onBind(intent: Intent): IBinder {
        return mMessenger.binder
    }

    override fun onCreate() {
        _player = MediaPlayer()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // 音声ファイルのURI
        val mediaFileUriStr = "android.resource://$packageName/${R.raw.mountain_stream}"
        // URIStrをもとに、URIオブジェクトを生成
        val mediaFileUri = Uri.parse(mediaFileUriStr)
        try{
            _player.setDataSource(this, mediaFileUri)
            // 非同期でのメディア再生準備が完了した際のリスナを設定
            _player.setOnPreparedListener {
                it.start()
            }
            // メディア再生が終了した際のリスナの設定
            _player.setOnCompletionListener {
                if(!_player.isLooping){
                    stopSelf()
                }
            }
        }catch (e :IOException){
            e.printStackTrace()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        if(_player.isPlaying){
            _player.stop()
        }
        _player.release()
    }

}

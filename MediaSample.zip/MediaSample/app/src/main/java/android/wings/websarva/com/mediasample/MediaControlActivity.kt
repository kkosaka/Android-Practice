package android.wings.websarva.com.mediasample

import android.content.Intent
import android.content.ServiceConnection
import android.media.MediaPlayer
import android.net.Uri
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.Button
import android.widget.Switch
import java.io.IOException
import android.content.ComponentName
import android.content.Context
import android.content.Context.BIND_AUTO_CREATE
import android.os.*


class MediaControlActivity : AppCompatActivity() {
    // メディアプレイヤーフィールド
//    private lateinit var _player: MediaPlayer
    // 再生・一時停止ボタンフィールド
    private lateinit var _btPlay: Button
    // 戻るボタンフィールド
    private lateinit var _btBack: Button
    // 進むボタンフィールド
    private lateinit var _btForward: Button

    private var mService: Messenger? = null
    private var mBound = false
    private var isPlaying = false

    /**
     * Class for interacting with the main interface of the service.
     */
    private val mConnection = object : ServiceConnection {
        override fun onServiceConnected(className: ComponentName, service: IBinder) {
            mService = Messenger(service)
            mBound = true
        }
        override fun onServiceDisconnected(arg0: ComponentName) {
            mService = null
            mBound = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_media_control)
        _btPlay = findViewById(R.id.btPlay)
        _btPlay.isEnabled = true
        if(isPlaying) _btPlay.setText(R.string.bt_play_pause)
        else _btPlay.setText(R.string.bt_play_play)
//        // スイッチを取得
//        val loopSwitch: Switch = findViewById(R.id.swLoop)
//        loopSwitch.setOnCheckedChangeListener { buttonView, isChecked ->
//            val intent = Intent(this, SoundManageService::class.java)
//            _player.isLooping = isChecked
//        }
    }

    override fun onStart() {
        super.onStart()
        // Bind to the service
        bindService(
            Intent(this, SoundManageService::class.java), mConnection,
            Context.BIND_AUTO_CREATE
        )
    }

    override fun onStop() {
        super.onStop()
        if(mBound){
            unbindService(mConnection)
            mBound = false
        }
    }

    fun onPlayButtonClick(view: View){
        if(!mBound) return
        // 再生中
        if(isPlaying){
            sendStatusToMediaService(SoundManageService.MEDIA_STOP)
            _btPlay.setText(R.string.bt_play_play)
        }
        // 停止中
        else{
            sendStatusToMediaService(SoundManageService.MEDIA_PLAY)
            _btPlay.setText(R.string.bt_play_pause)
        }
    }

    private fun sendStatusToMediaService(status: Int){
        val msg = Message.obtain(null, status, 0, 0)
        try{
            mService?.send(msg)
        }catch (e: RemoteException){
            e.printStackTrace()
        }
    }

    fun onBackButtonClick(view: View){
//        _player.seekTo(0)
    }

    fun onForwardButtonClick(view: View){
//        _player.seekTo(_player.duration)
//        if(!_player.isPlaying){
//            _player.start()
//        }
    }

}
